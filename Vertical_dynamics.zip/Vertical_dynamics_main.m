%%%% 汽车系统动力学-垂向动力学建模分析与半主动悬架控制 %%%%
% 2023.6.26
% 作者：郑鑫源 胡星宇
% 将Simulink文件与代码文件放入同一个文件夹，调整path变量后，一键运行(F5)出图
% MATLAB版本: R2022a

%% 初始化
clear;
clc;
path="E:\TJU第2学期\车辆系统动力学\vertical_dynamics";    %Simulink文件所在路径与图片储存路径
simT=10;    % 随机路面Simulink仿真时间
cd(path);

%% 状态空间方程
syms dzs zs
syms dzb zb
syms dphib phib
syms dztf ztf
syms dztr ztr
% syms qf qr

mb=1380; Ib=2444; ls=0.5; kf=17000; cf=1500; lf=1.25; kr=22000; cr=1500; lr=1.51;
mtf=81; ktf=384000; mtr=91; ktr=384000; ms=12; ks=17000; cs=100;
H=0.1; L=0.5; Lp=5; alpha=0.12; beta=0.006;
v=10;

A=[0 1 zeros(1,8);
    -ks/ms -cs/ms ks/ms cs/ms ks*ls/ms cs*ls/ms zeros(1,4);
    zeros(1,3) 1 zeros(1,6);
    ks/mb cs/mb -(kf+kr+ks)/mb -(cf+cr+cs)/mb (kf*lf-kr*lr-ks*ls)/mb (cf*lf-cr*lr-cs*ls)/mb kf/mb cf/mb kr/mb cr/mb;
    zeros(1,5) 1 zeros(1,4);
    ks*ls/Ib cs*ls/Ib (kf*lf-kr*lr-ks*ls)/Ib (cf*lf-cr*lr-cs*ls)/Ib -(kf*lf^2+kr*lr^2+ks*ls^2)/Ib -(cf*lf^2+cr*lr^2+cs*ls^2)/Ib -kf*lf/Ib -cf*lf/Ib kr*lr/Ib cr*lr/Ib;
    zeros(1,7) 1 zeros(1,2);
    0 0 kf/mtf cf/mtf -kf*lf/mtf -cf*lf/mtf -(kf+ktf)/mtf -cf/mtf 0 0;
    zeros(1,9) 1;
    0 0 kr/mtr cr/mtr kr*lr/mtr cr*lr/mtr 0 0 -(kr+ktr)/mtr -cr/mtr];

B=[zeros(7,2);
    ktf/mtf 0;
    0 0;
    0 ktr/mtr];

C=eye(10);

D=zeros(10,2);

%% 固有频率、主振型求解
A5=[ms mb Ib mtf mtr];
M5=diag(A5);
K5=-[-ks ks ks*ls 0 0;
    ks -(kf+kr+ks) kf*lf-kr*lr-ks*ls kf kr;
    ks*ls kf*lf-kr*lr-ks*ls -(kf*lf^2+kr*lr^2+ks*ls^2) -kf*lf kr*lr;
    0 kf -kf*lf -(kf+ktf) 0;
    0 kr kr*lr 0 -(kr+ktr)];
C5=-[-cs cs cs*ls 0 0;
    cs -(cf+cr+cs) cf*lf-cr*lr-cs*ls -cf*lf cr*lr;
    cs*ls cf*lf-cr*lr-cs*ls -(cf*lf^2+cr*lr^2+cs*ls^2) -cf*lf cr*lr;
    0 cf -cf*lf -cf 0;
    0 cr cr*lr 0 -cr];
H5=M5\K5;
[A0,d0]=eig(H5);
n=size(H5);
p=zeros(5,1);
for k=1:n
    p(k)=d0(k,k);
    A0(:,k)=A0(:,k)/max(abs(A0(:,k)));%进行矩阵的归一化处理
end
for j=1:n-1
    for k=j+1:n
        if p(j)>p(k)
            t=p(k);
            p(k)=p(j);
            p(j)=t;
            q=A0(:,k);
            A0(:,k)=A0(:,j); 
            A0(:,j)=q;
        end
    end
end
p;  %圆频率
A0;  %主振型
f=sqrt(abs(p))/(2*pi()) %时间频率

%% 主振型 画图
for k=1:5
      figure(k)
      set(gcf,'position',[5 45 1200 900]);
      plot(A0(:,k),'-*','LineWidth',3,'MarkerSize',22);
      set(gca,'FontName','Times','fontsize',32,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on');
      xlabel('主振型','FontName','宋体','FontWeight','bold','fontsize',42);
      grid on;
 end

%% 关闭图窗
close all;

%% 偏频
K5P=-[-ks 0 0 0 0;
    0 -(kf+kr+ks) 0 0 0;
    0 0 -(kf*lf^2+kr*lr^2+ks*ls^2) 0 0;
    0 0 0 -(kf+ktf) 0;
    0 0 0 0 -(kr+ktr)];
C5P=-[-cs 0 0 0 0;
    0 -(cf+cr+cs) 0 0 0;
    0 0 -(cf*lf^2+cr*lr^2+cs*ls^2) 0 0;
    0 0 0 -cf 0;
    0 0 0 0 -cr];
H5P=M5\K5P;
[AP,dP]=eig(H5P);
n=size(H5P);
pP=zeros(5,1);
for k=1:n
    pP(k)=dP(k,k);
    AP(:,k)=AP(:,k)/max(abs(AP(:,k)));%进行矩阵的归一化处理
end
for j=1:n-1
    for k=j+1:n
        if pP(j)>pP(k)
            t=pP(k);
            pP(k)=pP(j);
            pP(j)=t;
            qP=AP(:,k);
            AP(:,k)=AP(:,j);
            AP(:,j)=qP;
        end
    end
end
pP;  %圆频率
AP;  %主振型
fP=sqrt(abs(pP))/(2*pi()) %时间频率

%% 频率响应函数
Q = [0,0;
    0,0;
    0,0;
    ktf,0;
    0,ktr];
s = tf('s');
Hs = M5*s^2 + C5*s + K5;
G = Hs\Q;

%前轮路面不平度位移输入-人体(座椅)位移
figure(6)
GF_H = G(1,1);
opts = bodeoptions('cstprefs');
opts.Title.String = '前轮路面不平度位移输入-人体(座椅)位移频域特性';
opts.FreqUnits = 'Hz';
opts.FreqScale = 'linear';
opts.MagUnits = 'abs';
opts.MagScale = 'linear';
opts.Xlim = [0 20];
bodeplot(GF_H,opts);
% set(gca,'position',[5 45 1430 600]);
h = findobj(gcf, 'Type','line');
set(h, 'LineWidth', 2);
% set(h,'color','b'); 
% saveas(gcf,[path,'前轮路面不平度位移输入-人体(座椅)位移频域特性.fig']);
grid on;
saveas(gcf,'前轮路面不平度位移输入-座椅位移频域特性.png');

%后轮路面不平度位移输入-人体(座椅)位移
figure(7)
GR_H = G(1,2);
opts = bodeoptions('cstprefs');
opts.Title.String = '后轮路面不平度位移输入-人体(座椅)位移频域特性';
opts.FreqUnits = 'Hz';
opts.FreqScale = 'linear';
opts.MagUnits = 'abs';
opts.MagScale = 'linear';
opts.Xlim = [0 20];
bodeplot(GR_H,opts);
h = findobj(gcf, 'Type','line');
set(h, 'LineWidth', 2);
% set(h,'color','b'); 
grid on;
% saveas(gcf,[path,'后轮路面不平度位移输入-人体(座椅)位移频域特性.fig']);
saveas(gcf,'后轮路面不平度位移输入-座椅位移频域特性.png');

%前轮路面不平度位移输入-车身垂向位移
figure(8)
GF_C = G(2,1);
opts = bodeoptions('cstprefs');
opts.Title.String = '前轮路面不平度位移输入-车身垂向位移频域特性';
opts.FreqUnits = 'Hz';
opts.FreqScale = 'linear';
opts.MagUnits = 'abs';
opts.MagScale = 'linear';
opts.Xlim = [0 20];
bodeplot(GF_C,opts);
h = findobj(gcf, 'Type','line');
set(h, 'LineWidth', 2);
% set(h,'color','b'); 
grid on;
% saveas(gcf,[path,'\前轮路面不平度位移输入-车身垂向位移频域特性.fig']);
saveas(gcf,'前轮路面不平度位移输入-车身垂向位移频域特性.png');

%后轮路面不平度位移输入-车身垂向位移
figure(9)
GR_C = G(2,2);
opts = bodeoptions('cstprefs');
opts.Title.String = '后轮路面不平度位移输入-车身垂向位移频域特性';
opts.FreqUnits = 'Hz';
opts.FreqScale = 'linear';
opts.MagUnits = 'abs';
opts.MagScale = 'linear';
opts.Xlim = [0 20];
bodeplot(GR_C,opts);
h = findobj(gcf, 'Type','line');
set(h, 'LineWidth', 2);
% set(h,'color','b'); 
grid on;
% saveas(gcf,[path,'\后轮路面不平度位移输入-车身垂向位移频域特性.fig']);
saveas(gcf,'后轮路面不平度位移输入-车身垂向位移频域特性.png');

%前轮路面不平度位移输入-车身俯仰角
figure(10)
GF_CB = G(3,1);
opts = bodeoptions('cstprefs');
opts.Title.String = '前轮路面不平度位移输入-车身俯仰角频域特性';
opts.FreqUnits = 'Hz';
opts.FreqScale = 'linear';
opts.MagUnits = 'abs';
opts.MagScale = 'linear';
opts.Xlim = [0 20];
bodeplot(GF_CB,opts);
h = findobj(gcf, 'Type','line');
set(h, 'LineWidth', 2);
% set(h,'color','b'); 
grid on;
% saveas(gcf,[path,'\前轮路面不平度位移输入-车身俯仰角频域特性.fig']);
saveas(gcf,'前轮路面不平度位移输入-车身俯仰角频域特性.png');

%后轮路面不平度位移输入-车身俯仰角
figure(11)
GR_CB = G(3,2);
opts = bodeoptions('cstprefs');
opts.Title.String = '后轮路面不平度位移输入-车身俯仰角频域特性';
opts.FreqUnits = 'Hz';
opts.FreqScale = 'linear';
opts.MagUnits = 'abs';
opts.MagScale = 'linear';
opts.Xlim = [0 20];
bodeplot(GR_CB,opts);
h = findobj(gcf, 'Type','line');
set(h, 'LineWidth', 2);
% set(h,'color','b'); 
grid on;
% saveas(gcf,[path,'\后轮路面不平度位移输入-车身俯仰角频域特性.fig']);
saveas(gcf,'后轮路面不平度位移输入-车身俯仰角频域特性.png');

%前轮路面不平度位移输入-前轮垂向位移
figure(12)
GF_FT = G(4,1);
opts = bodeoptions('cstprefs');
opts.Title.String = '前轮路面不平度位移输入-前轮垂向位移频域特性';
opts.FreqUnits = 'Hz';
opts.FreqScale = 'linear';
opts.MagUnits = 'abs';
opts.MagScale = 'linear';
opts.Xlim = [0 20];
bodeplot(GF_FT,opts);
h = findobj(gcf, 'Type','line');
set(h, 'LineWidth', 2);
% set(h,'color','b'); 
grid on;
% saveas(gcf,[path,'\前轮路面不平度位移输入-前轮垂向位移频域特性.fig']);
saveas(gcf,'前轮路面不平度位移输入-前轮垂向位移频域特性.png');

%后轮路面不平度位移输入-前轮垂向位移
figure(13)
GR_FT = G(4,2);
opts = bodeoptions('cstprefs');
opts.Title.String = '后轮路面不平度位移输入-前轮垂向位移频域特性';
opts.FreqUnits = 'Hz';
opts.FreqScale = 'linear';
opts.MagUnits = 'abs';
opts.MagScale = 'linear';
opts.Xlim = [0 20];
bodeplot(GR_FT,opts);
h = findobj(gcf, 'Type','line');
set(h, 'LineWidth', 2);
% set(h,'color','b'); 
grid on;
% saveas(gcf,[path,'\后轮路面不平度位移输入-前轮垂向位移频域特性.fig']);
saveas(gcf,'后轮路面不平度位移输入-前轮垂向位移频域特性.png');

%前轮路面不平度位移输入-后轮垂向位移
figure(14)
GF_RT = G(5,1);
opts = bodeoptions('cstprefs');
opts.Title.String = '前轮路面不平度位移输入-后轮垂向位移频域特性';
opts.FreqUnits = 'Hz';
opts.FreqScale = 'linear';
opts.MagUnits = 'abs';
opts.MagScale = 'linear';
opts.Xlim = [0 20];
bodeplot(GF_RT,opts);
h = findobj(gcf, 'Type','line');
set(h, 'LineWidth', 2);
% set(h,'color','b'); 
grid on;
% saveas(gcf,[path,'\前轮路面不平度位移输入-后轮垂向位移频域特性.fig']);
saveas(gcf,'前轮路面不平度位移输入-后轮垂向位移频域特性.png');

%后轮路面不平度位移输入-后轮垂向位移
figure(15)
GR_RT = G(5,2);
opts = bodeoptions('cstprefs');
opts.Title.String = '后轮路面不平度位移输入-后轮垂向位移频域特性';
opts.FreqUnits = 'Hz';
opts.FreqScale = 'linear';
opts.MagUnits = 'abs';
opts.MagScale = 'linear';
opts.Xlim = [0 20];
bodeplot(GR_RT,opts);
h = findobj(gcf, 'Type','line');
set(h, 'LineWidth', 2);
% set(h,'color','b'); 
grid on
% saveas(gcf,[path,'\后轮路面不平度位移输入-后轮垂向位移频域特性.fig']);
saveas(gcf,'后轮路面不平度位移输入-后轮垂向位移频域特性.png');

%% v=10m/s通过随机路面 各自由度响应
close all;
v=10;
out_cr_10=sim('Vertical_dynamics_customed_road.slx');
figure(16)
set(gcf,'position',[5 45 1430 980]);

%前轮垂向位移响应
subplot(3,2,1)
plot(v*out_cr_10.tout,out_cr_10.ztf,"LineWidth",2);
grid on;
xlim([0 50]);
ylim([-0.2 0.2]);
title('\fontname{黑体}前轮垂向位移响应\fontname{Times} (v=10m/s)','FontWeight','bold','fontsize',22);
set(gca,'FontName','Times','fontsize',22,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);

%后轮垂向位移响应
subplot(3,2,2)
plot(v*out_cr_10.tout,out_cr_10.ztr,"LineWidth",2);
grid on;
xlim([0 50]);
ylim([-0.2 0.2]);
title('\fontname{黑体}后轮垂向位移响应\fontname{Times} (v=10m/s)','FontWeight','bold','fontsize',22);
set(gca,'FontName','Times','fontsize',22,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);

%车身垂向位移响应
subplot(3,2,3)
plot(v*out_cr_10.tout,out_cr_10.zb,"LineWidth",2);
grid on;
xlim([0 50]);
ylim([-0.03 0.03]);
title('\fontname{黑体}车身垂向位移响应\fontname{Times} (v=10m/s)','FontWeight','bold','fontsize',22);
set(gca,'FontName','Times','fontsize',22,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);

%车身俯仰角响应
subplot(3,2,4)
plot(v*out_cr_10.tout,out_cr_10.phib*180/pi,"LineWidth",2);
grid on;
xlim([0 50]);
ylim([-0.8 0.8]);
title('\fontname{黑体}车身俯仰角响应\fontname{Times} (v=10m/s)','FontWeight','bold','fontsize',22);
set(gca,'FontName','Times','fontsize',22,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}角度\fontname{Times} (°)','FontWeight','bold','fontsize',20);

%座椅垂向位移响应
subplot(3,2,5)
plot(v*out_cr_10.tout,out_cr_10.zs,"LineWidth",2);
grid on;
xlim([0 50]);
ylim([-0.04 0.04]);
title('\fontname{黑体}座椅垂向位移响应\fontname{Times} (v=10m/s)','FontWeight','bold','fontsize',22);
set(gca,'FontName','Times','fontsize',22,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);

saveas(gcf,'减速带 v=10 瞬态位移响应.png');

%% 0-30m/s 不同自由度VDV响应-速度影响关系 (以0.5m/s为间隔)
close all;
VDVztf=zeros(61,1);
VDVztr=zeros(61,1);
VDVzb=zeros(61,1);
VDVphib=zeros(61,1);
VDVzs=zeros(61,1);
for i=1:1:61
    v=0.5*(i-1);
    out_cr=sim('Vertical_dynamics_customed_road.slx');
    VDVztf(i)=max(out_cr.VDVztf);
    VDVztr(i)=max(out_cr.VDVztr);
    VDVzb(i)=max(out_cr.VDVzb);
    VDVphib(i)=max(out_cr.VDVphib);
    VDVzs(i)=max(out_cr.VDVzs);
end

v=0:0.5:30;
figure(17)
set(gcf,'position',[5 45 1430 980]);

%前轮垂向VDV
subplot(3,2,1)
plot(v,VDVztf,"LineWidth",2);
grid on;
xlim([0 30]);
ylim([0 300]);
title('\fontname{黑体}前轮垂向\fontname{Times} VDV','FontWeight','bold','fontsize',24);
set(gca,'FontName','Times','fontsize',18,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}\fontname{Times}VDV (m/s^{1.75})','FontWeight','bold','fontsize',20);

%后轮垂向VDV
subplot(3,2,2)
plot(v,VDVztr,"LineWidth",2);
grid on;
xlim([0 30]);
ylim([0 300]);
title('\fontname{黑体}后轮垂向\fontname{Times} VDV','FontWeight','bold','fontsize',24);
set(gca,'FontName','Times','fontsize',18,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}\fontname{Times}VDV (m/s^{1.75})','FontWeight','bold','fontsize',20);

%车身垂向VDV
subplot(3,2,3)
plot(v,VDVzb,"LineWidth",2);
grid on;
xlim([0 30]);
ylim([0 6]);
title('\fontname{黑体}车身垂向\fontname{Times} VDV','FontWeight','bold','fontsize',24);
set(gca,'FontName','Times','fontsize',18,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}\fontname{Times}VDV (m/s^{1.75})','FontWeight','bold','fontsize',20);

%车身俯仰VDV
subplot(3,2,4)
plot(v,VDVphib,"LineWidth",2);
grid on;
xlim([0 30]);
ylim([0 4.5]);
title('\fontname{黑体}车身俯仰\fontname{Times} VDV','FontWeight','bold','fontsize',24);
set(gca,'FontName','Times','fontsize',18,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}\fontname{Times}VDV (rad/s^{1.75})','FontWeight','bold','fontsize',20);

%座椅垂向VDV
subplot(3,2,5)
plot(v,VDVzs,"LineWidth",2);
grid on;
xlim([0 30]);
ylim([0 8]);
title('\fontname{黑体}座椅垂向\fontname{Times} VDV','FontWeight','bold','fontsize',24);
set(gca,'FontName','Times','fontsize',18,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}\fontname{Times}VDV (m/s^{1.75})','FontWeight','bold','fontsize',20);

saveas(gcf,'v=0-30 减速带 VDV.png');

%% v=10m/s通过随机路面 各自由度响应
close all;
v=10;
out_rr_10=sim('Vertical_dynamics_random_road.slx');
figure(18)
set(gcf,'position',[5 45 1430 980]);

%前轮垂向位移响应
subplot(3,2,1)
plot(v*out_rr_10.tout,out_rr_10.ztf,"LineWidth",2);
grid on;
xlim([0 50]);
ylim([-0.15 0.25]);
title('\fontname{黑体}前轮垂向位移响应\fontname{Times} (v=10m/s)','FontWeight','bold','fontsize',22);
set(gca,'FontName','Times','fontsize',22,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);

%后轮垂向位移响应
subplot(3,2,2)
plot(v*out_rr_10.tout,out_rr_10.ztr,"LineWidth",2);
grid on;
xlim([0 50]);
ylim([-0.15 0.25]);
title('\fontname{黑体}后轮垂向位移响应\fontname{Times} (v=10m/s)','FontWeight','bold','fontsize',22);
set(gca,'FontName','Times','fontsize',22,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);

%车身垂向位移响应
subplot(3,2,3)
plot(v*out_rr_10.tout,out_rr_10.zb,"LineWidth",2);
grid on;
xlim([0 50]);
ylim([-0.15 0.25]);
title('\fontname{黑体}车身垂向位移响应\fontname{Times} (v=10m/s)','FontWeight','bold','fontsize',22);
set(gca,'FontName','Times','fontsize',22,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);

%车身俯仰角响应
subplot(3,2,4)
plot(v*out_rr_10.tout,out_rr_10.phib*180/pi,"LineWidth",2);
grid on;
xlim([0 50]);
ylim([-1.1 1.1]);
title('\fontname{黑体}车身俯仰角响应\fontname{Times} (v=10m/s)','FontWeight','bold','fontsize',22);
set(gca,'FontName','Times','fontsize',22,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}角度\fontname{Times} (°)','FontWeight','bold','fontsize',20);

%座椅垂向位移响应
subplot(3,2,5)
plot(v*out_rr_10.tout,out_rr_10.zs,"LineWidth",2);
grid on;
xlim([0 50]);
ylim([-0.15 0.25]);
title('\fontname{黑体}座椅垂向位移响应\fontname{Times} (v=10m/s)','FontWeight','bold','fontsize',22);
set(gca,'FontName','Times','fontsize',22,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);

saveas(gcf,'C级随机路面 v=10 瞬态位移响应.png');

%% 0-30m/s 随机路面 不同自由度位移均方值响应-速度影响关系 (以0.5m/s为间隔)
close all
MSztf=zeros(61,1);
MSztr=zeros(61,1);
MSzb=zeros(61,1);
MSphib=zeros(61,1);
MSzs=zeros(61,1);
for i=1:1:61
    v=0.5*(i-1);
    out_rr=sim('Vertical_dynamics_random_road.slx');
    sumztf2=0;
    sumztr2=0;
    sumzb2=0;
    sumphib2=0;
    sumzs2=0;
    for j=1:length(out_rr.tout)
        sumztf2=out_rr.ztf(j)^2+sumztf2;
        sumztr2=out_rr.ztr(j)^2+sumztr2;
        sumzb2=out_rr.zb(j)^2+sumzb2;
        sumphib2=out_rr.phib(j)^2+sumphib2;
        sumzs2=out_rr.zs(j)^2+sumzs2;
    end
    MSztf(i)=sumztf2/length(out_rr.tout);
    MSztr(i)=sumztr2/length(out_rr.tout);
    MSzb(i)=sumzb2/length(out_rr.tout);
    MSphib(i)=sumphib2/length(out_rr.tout);
    MSzs(i)=sumzs2/length(out_rr.tout);
end

%% 均方值(Mean Square Value)
v=0:0.5:30;
figure(19)
set(gcf,'position',[5 45 1430 980]);

%前轮垂向位移-均方值
subplot(3,2,1)
plot(v,MSztf,"LineWidth",2);
grid on;
xlim([0 30]);
ylim([0 0.1]);
title('\fontname{黑体}前轮垂向位移-均方值\fontname{Times}','FontWeight','bold','fontsize',22);
set(gca,'FontName','Times','fontsize',22,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}均方值\fontname{Times} (m^2/s^2)','FontWeight','bold','fontsize',20);

%后轮垂向位移-均方值
subplot(3,2,2)
plot(v,MSztr,"LineWidth",2);
grid on;
xlim([0 30]);
ylim([0 0.1]);
title('\fontname{黑体}后轮垂向位移-均方值\fontname{Times}','FontWeight','bold','fontsize',22);
set(gca,'FontName','Times','fontsize',22,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}均方值\fontname{Times} (m^2/s^2)','FontWeight','bold','fontsize',20);

%车身垂向位移-均方值
subplot(3,2,3)
plot(v,MSzb,"LineWidth",2);
grid on;
xlim([0 30]);
ylim([0 0.1]);
title('\fontname{黑体}车身垂向位移-均方值\fontname{Times}','FontWeight','bold','fontsize',22);
set(gca,'FontName','Times','fontsize',22,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}均方值\fontname{Times} (m^2/s^2)','FontWeight','bold','fontsize',20);

%车身俯仰角-均方值
subplot(3,2,4)
plot(v,MSphib,"LineWidth",2);
grid on;
xlim([0 30]);
ylim([0 2.5e-4]);
title('\fontname{黑体}车身俯仰角-均方值\fontname{Times}','FontWeight','bold','fontsize',22);
set(gca,'FontName','Times','fontsize',22,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}均方值\fontname{Times} (rad^2/s^2)','FontWeight','bold','fontsize',20);

%座椅垂向位移-均方值
subplot(3,2,5)
plot(v,MSzs,"LineWidth",2);
grid on;
xlim([0 30]);
ylim([0 0.1]);
title('\fontname{黑体}座椅垂向位移-均方值\fontname{Times}','FontWeight','bold','fontsize',22);
set(gca,'FontName','Times','fontsize',22,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
xlabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
ylabel('\fontname{宋体}均方值\fontname{Times} (m^2/s^2)','FontWeight','bold','fontsize',20);

%% 典型路面瞬态响应 速度影响分析-前轮响应 天棚原理控制器效果对比
close all;
for i=1:1:61
    v=0.5*(i-1);
    out_cr_sh=sim('Vertical_dynamics_customed_road_skyhook_controller.slx');
    out_cr=sim('Vertical_dynamics_customed_road.slx');
    figure(20)
    set(gcf,'position',[5 50 2000 550]);

    %位移
    subplot(1,3,1)
    if i>=2
        set(pshx(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(px(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshx(i)=plot(v*out_cr_sh.tout,out_cr_sh.ztf,"LineWidth",1.8,"Color",'#D95319');
    px(i)=plot(v*out_cr.tout,out_cr.ztf,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}典型路面-前轮垂向位移响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshx(i) px(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    xlim([0 30]);

    %速度
    subplot(1,3,2)
    if i>=2
        set(pshv(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pv(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshv(i)=plot(v*out_cr_sh.tout,out_cr_sh.dztf,"LineWidth",1.8,"Color",'#D95319');
    pv(i)=plot(v*out_cr.tout,out_cr.dztf,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}典型路面-前轮垂向速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshv(i) pv(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    xlim([0 30]);

    %加速度
    subplot(1,3,3)
    if i>=2
        set(psha(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pa(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    psha(i)=plot(v*out_cr_sh.tout,out_cr_sh.ddztf,"LineWidth",1.8,"Color",'#D95319');
    pa(i)=plot(v*out_cr.tout,out_cr.ddztf,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}加速度\fontname{Times} (m/s^2)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}典型路面-前轮垂向加速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([psha(i) pa(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    xlim([0 30]);

end
hold off;

saveas(gcf,'减速带 前轮响应图 天棚原理控制器效果对比.png');

%% 典型路面瞬态响应 速度影响分析-后轮响应 天棚原理控制器效果对比
close all;
for i=1:1:61
    v=0.5*(i-1);
    out_cr_sh=sim('Vertical_dynamics_customed_road_skyhook_controller.slx');
    out_cr=sim('Vertical_dynamics_customed_road.slx');
    figure(21)
    set(gcf,'position',[5 50 2000 550]);

    %位移
    subplot(1,3,1)
    if i>=2
        set(pshx(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(px(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshx(i)=plot(v*out_cr_sh.tout,out_cr_sh.ztr,"LineWidth",1.8,"Color",'#D95319');
    px(i)=plot(v*out_cr.tout,out_cr.ztr,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}典型路面-后轮垂向位移响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshx(i) px(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    xlim([0 30]);

    %速度
    subplot(1,3,2)
    if i>=2
        set(pshv(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pv(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshv(i)=plot(v*out_cr_sh.tout,out_cr_sh.dztr,"LineWidth",1.8,"Color",'#D95319');
    pv(i)=plot(v*out_cr.tout,out_cr.dztr,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}典型路面-后轮垂向速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshv(i) pv(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    xlim([0 30]);

    %加速度
    subplot(1,3,3)
    if i>=2
        set(psha(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pa(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    psha(i)=plot(v*out_cr_sh.tout,out_cr_sh.ddztr,"LineWidth",1.8,"Color",'#D95319');
    pa(i)=plot(v*out_cr.tout,out_cr.ddztr,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}加速度\fontname{Times} (m/s^2)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}典型路面-后轮垂向加速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([psha(i) pa(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    xlim([0 30]);

end
hold off;

saveas(gcf,'减速带 后轮响应图 天棚原理控制器效果对比.png');

%% 典型路面瞬态响应 速度影响分析-车身垂向响应 天棚原理控制器效果对比
close all;
for i=1:1:61
    v=0.5*(i-1);
    out_cr_sh=sim('Vertical_dynamics_customed_road_skyhook_controller.slx');
    out_cr=sim('Vertical_dynamics_customed_road.slx');
    figure(22)
    set(gcf,'position',[5 50 2000 550]);

    %位移
    subplot(1,3,1)
    if i>=2
        set(pshx(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(px(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshx(i)=plot(v*out_cr_sh.tout,out_cr_sh.zb,"LineWidth",1.8,"Color",'#D95319');
    px(i)=plot(v*out_cr.tout,out_cr.zb,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}典型路面-车身垂向位移响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshx(i) px(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    xlim([0 30]);

    %速度
    subplot(1,3,2)
    if i>=2
        set(pshv(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pv(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshv(i)=plot(v*out_cr_sh.tout,out_cr_sh.dzb,"LineWidth",1.8,"Color",'#D95319');
    pv(i)=plot(v*out_cr.tout,out_cr.dzb,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}典型路面-车身垂向速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshv(i) pv(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    xlim([0 30]);

    %加速度
    subplot(1,3,3)
    if i>=2
        set(psha(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pa(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    psha(i)=plot(v*out_cr_sh.tout,out_cr_sh.ddzb,"LineWidth",1.8,"Color",'#D95319');
    pa(i)=plot(v*out_cr.tout,out_cr.ddzb,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}加速度\fontname{Times} (m/s^2)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}典型路面-车身垂向加速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([psha(i) pa(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    xlim([0 30]);

end
hold off;

saveas(gcf,'减速带 车身垂向响应图 天棚原理控制器效果对比.png');

%% 典型路面瞬态响应 速度影响分析-车身俯仰角响应 天棚原理控制器效果对比
close all;
for i=1:1:61
    v=0.5*(i-1);
    out_cr_sh=sim('Vertical_dynamics_customed_road_skyhook_controller.slx');
    out_cr=sim('Vertical_dynamics_customed_road.slx');
    figure(23)
    set(gcf,'position',[5 50 2000 550]);

    %位移
    subplot(1,3,1)
    if i>=2
        set(pshx(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(px(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshx(i)=plot(v*out_cr_sh.tout,out_cr_sh.phib,"LineWidth",1.8,"Color",'#D95319');
    px(i)=plot(v*out_cr.tout,out_cr.phib,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}角度\fontname{Times} (rad)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}典型路面-车身俯仰角度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshx(i) px(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    xlim([0 30]);

    %速度
    subplot(1,3,2)
    if i>=2
        set(pshv(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pv(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshv(i)=plot(v*out_cr_sh.tout,out_cr_sh.dphib,"LineWidth",1.8,"Color",'#D95319');
    pv(i)=plot(v*out_cr.tout,out_cr.dphib,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}角速度\fontname{Times} (rad/s)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}典型路面-车身俯仰角速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshv(i) pv(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    xlim([0 30]);

    %加速度
    subplot(1,3,3)
    if i>=2
        set(psha(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pa(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    psha(i)=plot(v*out_cr_sh.tout,out_cr_sh.ddphib,"LineWidth",1.8,"Color",'#D95319');
    pa(i)=plot(v*out_cr.tout,out_cr.ddphib,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}角加速度\fontname{Times} (rad/s^2)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}典型路面-车身俯仰角加速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([psha(i) pa(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    xlim([0 30]);

end
hold off;

saveas(gcf,'减速带 车身俯仰角响应图 天棚原理控制器效果对比.png');

%% 典型路面瞬态响应 速度影响分析-座椅响应 天棚原理控制器效果对比
close all;
for i=1:1:61
    v=0.5*(i-1);
    out_cr_sh=sim('Vertical_dynamics_customed_road_skyhook_controller.slx');
    out_cr=sim('Vertical_dynamics_customed_road.slx');
    figure(24)
    set(gcf,'position',[5 50 2000 550]);

    %位移
    subplot(1,3,1)
    if i>=2
        set(pshx(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(px(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshx(i)=plot(v*out_cr_sh.tout,out_cr_sh.zs,"LineWidth",1.8,"Color",'#D95319');
    px(i)=plot(v*out_cr.tout,out_cr.zs,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}典型路面-座椅垂向位移响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshx(i) px(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    xlim([0 30]);

    %速度
    subplot(1,3,2)
    if i>=2
        set(pshv(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pv(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshv(i)=plot(v*out_cr_sh.tout,out_cr_sh.dzs,"LineWidth",1.8,"Color",'#D95319');
    pv(i)=plot(v*out_cr.tout,out_cr.dzs,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}典型路面-座椅垂向速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshv(i) pv(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    xlim([0 30]);

    %加速度
    subplot(1,3,3)
    if i>=2
        set(psha(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pa(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    psha(i)=plot(v*out_cr_sh.tout,out_cr_sh.ddzs,"LineWidth",1.8,"Color",'#D95319');
    pa(i)=plot(v*out_cr.tout,out_cr.ddzs,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}前进距离\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}加速度\fontname{Times} (m/s^2)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}典型路面-座椅垂向加速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([psha(i) pa(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    xlim([0 30]);

end
hold off;

saveas(gcf,'减速带 座椅响应图 天棚原理控制器效果对比.png');

%% 随机路面瞬态响应 速度影响分析-前轮响应 天棚原理控制器效果对比
close all;
for i=1:1:61
    v=0.5*(i-1);
    out_rr_sh=sim('Vertical_dynamics_random_road_skyhook_controller.slx');
    out_rr=sim('Vertical_dynamics_random_road.slx');
    figure(25)
    set(gcf,'position',[5 50 2000 550]);

    %位移
    subplot(1,3,1)
    if i>=2
        set(pshx(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(px(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshx(i)=plot(out_rr_sh.tout,out_rr_sh.ztf,"LineWidth",1.8,"Color",'#D95319');
    px(i)=plot(out_rr.tout,out_rr.ztf,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}时间\fontname{Times} (s)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}随机路面-前轮垂向位移响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshx(i) px(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    

    %速度
    subplot(1,3,2)
    if i>=2
        set(pshv(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pv(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshv(i)=plot(out_rr_sh.tout,out_rr_sh.dztf,"LineWidth",1.8,"Color",'#D95319');
    pv(i)=plot(out_rr.tout,out_rr.dztf,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}时间\fontname{Times} (s)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}随机路面-前轮垂向速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshv(i) pv(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    

    %加速度
    subplot(1,3,3)
    if i>=2
        set(psha(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pa(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    psha(i)=plot(out_rr_sh.tout,out_rr_sh.ddztf,"LineWidth",1.8,"Color",'#D95319');
    pa(i)=plot(out_rr.tout,out_rr.ddztf,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}时间\fontname{Times} (s)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}加速度\fontname{Times} (m/s^2)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}随机路面-前轮垂向加速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([psha(i) pa(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    

end
hold off;

saveas(gcf,'C级随机路面 前轮响应图 天棚原理控制器效果对比.png');

%% 随机路面瞬态响应 速度影响分析-后轮响应 天棚原理控制器效果对比
close all;
for i=1:1:61
    v=0.5*(i-1);
    out_rr_sh=sim('Vertical_dynamics_random_road_skyhook_controller.slx');
    out_rr=sim('Vertical_dynamics_random_road.slx');
    figure(26)
    set(gcf,'position',[5 50 2000 550]);

    %位移
    subplot(1,3,1)
    if i>=2
        set(pshx(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(px(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshx(i)=plot(out_rr_sh.tout,out_rr_sh.ztr,"LineWidth",1.8,"Color",'#D95319');
    px(i)=plot(out_rr.tout,out_rr.ztr,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}时间\fontname{Times} (s)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}随机路面-后轮垂向位移响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshx(i) px(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    

    %速度
    subplot(1,3,2)
    if i>=2
        set(pshv(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pv(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshv(i)=plot(out_rr_sh.tout,out_rr_sh.dztr,"LineWidth",1.8,"Color",'#D95319');
    pv(i)=plot(out_rr.tout,out_rr.dztr,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}时间\fontname{Times} (s)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}随机路面-后轮垂向速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshv(i) pv(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    

    %加速度
    subplot(1,3,3)
    if i>=2
        set(psha(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pa(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    psha(i)=plot(out_rr_sh.tout,out_rr_sh.ddztr,"LineWidth",1.8,"Color",'#D95319');
    pa(i)=plot(out_rr.tout,out_rr.ddztr,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}时间\fontname{Times} (s)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}加速度\fontname{Times} (m/s^2)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}随机路面-后轮垂向加速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([psha(i) pa(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    

end
hold off;

saveas(gcf,'C级随机路面 后轮响应图 天棚原理控制器效果对比.png');

%% 随机路面瞬态响应 速度影响分析-车身垂向响应 天棚原理控制器效果对比
close all;
for i=1:1:61
    v=0.5*(i-1);
    out_rr_sh=sim('Vertical_dynamics_random_road_skyhook_controller.slx');
    out_rr=sim('Vertical_dynamics_random_road.slx');
    figure(27)
    set(gcf,'position',[5 50 2000 550]);

    %位移
    subplot(1,3,1)
    if i>=2
        set(pshx(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(px(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshx(i)=plot(out_rr_sh.tout,out_rr_sh.zb,"LineWidth",1.8,"Color",'#D95319');
    px(i)=plot(out_rr.tout,out_rr.zb,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}时间\fontname{Times} (s)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}随机路面-车身垂向位移响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshx(i) px(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    

    %速度
    subplot(1,3,2)
    if i>=2
        set(pshv(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pv(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshv(i)=plot(out_rr_sh.tout,out_rr_sh.dzb,"LineWidth",1.8,"Color",'#D95319');
    pv(i)=plot(out_rr.tout,out_rr.dzb,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}时间\fontname{Times} (s)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}随机路面-车身垂向速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshv(i) pv(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    

    %加速度
    subplot(1,3,3)
    if i>=2
        set(psha(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pa(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    psha(i)=plot(out_rr_sh.tout,out_rr_sh.ddzb,"LineWidth",1.8,"Color",'#D95319');
    pa(i)=plot(out_rr.tout,out_rr.ddzb,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}时间\fontname{Times} (s)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}加速度\fontname{Times} (m/s^2)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}随机路面-车身垂向加速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([psha(i) pa(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    

end
hold off;

saveas(gcf,'C级随机路面 车身垂向响应图 天棚原理控制器效果对比.png');

%% 随机路面瞬态响应 速度影响分析-车身俯仰角响应 天棚原理控制器效果对比
close all;
for i=1:1:61
    v=0.5*(i-1);
    out_rr_sh=sim('Vertical_dynamics_random_road_skyhook_controller.slx');
    out_rr=sim('Vertical_dynamics_random_road.slx');
    figure(28)
    set(gcf,'position',[5 50 2000 550]);

    %位移
    subplot(1,3,1)
    if i>=2
        set(pshx(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(px(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshx(i)=plot(out_rr_sh.tout,out_rr_sh.phib,"LineWidth",1.8,"Color",'#D95319');
    px(i)=plot(out_rr.tout,out_rr.phib,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}时间\fontname{Times} (s)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}角度\fontname{Times} (rad)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}随机路面-车身俯仰角度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshx(i) px(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    

    %速度
    subplot(1,3,2)
    if i>=2
        set(pshv(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pv(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshv(i)=plot(out_rr_sh.tout,out_rr_sh.dphib,"LineWidth",1.8,"Color",'#D95319');
    pv(i)=plot(out_rr.tout,out_rr.dphib,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}时间\fontname{Times} (s)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}角速度\fontname{Times} (rad/s)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}随机路面-车身俯仰角速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshv(i) pv(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    

    %加速度
    subplot(1,3,3)
    if i>=2
        set(psha(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pa(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    psha(i)=plot(out_rr_sh.tout,out_rr_sh.ddphib,"LineWidth",1.8,"Color",'#D95319');
    pa(i)=plot(out_rr.tout,out_rr.ddphib,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}时间\fontname{Times} (s)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}角加速度\fontname{Times} (rad/s^2)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}随机路面-车身俯仰角加速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([psha(i) pa(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    

end
hold off;

saveas(gcf,'C级随机路面 车身俯仰角响应图 天棚原理控制器效果对比.png');

%% 随机路面瞬态响应 速度影响分析-座椅响应 天棚原理控制器效果对比
close all;
for i=1:1:61
    v=0.5*(i-1);
    out_rr_sh=sim('Vertical_dynamics_random_road_skyhook_controller.slx');
    out_rr=sim('Vertical_dynamics_random_road.slx');
    figure(29)
    set(gcf,'position',[5 50 2000 550]);

    %位移
    subplot(1,3,1)
    if i>=2
        set(pshx(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(px(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshx(i)=plot(out_rr_sh.tout,out_rr_sh.zs,"LineWidth",1.8,"Color",'#D95319');
    px(i)=plot(out_rr.tout,out_rr.zs,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}时间\fontname{Times} (s)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}位移\fontname{Times} (m)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}随机路面-座椅垂向位移响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshx(i) px(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    

    %速度
    subplot(1,3,2)
    if i>=2
        set(pshv(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pv(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    pshv(i)=plot(out_rr_sh.tout,out_rr_sh.dzs,"LineWidth",1.8,"Color",'#D95319');
    pv(i)=plot(out_rr.tout,out_rr.dzs,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}时间\fontname{Times} (s)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}速度\fontname{Times} (m/s)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}随机路面-座椅垂向速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([pshv(i) pv(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    

    %加速度
    subplot(1,3,3)
    if i>=2
        set(psha(i-1),"Color","#EDB120","LineWidth",0.7,"LineStyle",":");
        set(pa(i-1),"Color","#4DBEEE","LineWidth",0.7,"LineStyle",":");
    end
    %     clf;
    hold on;
    psha(i)=plot(out_rr_sh.tout,out_rr_sh.ddzs,"LineWidth",1.8,"Color",'#D95319');
    pa(i)=plot(out_rr.tout,out_rr.ddzs,"LineWidth",1.8,"Color",'#0072BD');
    set(gca,'FontName','Times','fontsize',20,'FontWeight','bold','GridLineStyle','--','LineWidth',1.1,'XMinorTick','on','YMinorTick','on','ZMinorTick','on','Box','on');
    xlabel('\fontname{宋体}时间\fontname{Times} (s)','FontWeight','bold','fontsize',20);
    ylabel('\fontname{宋体}加速度\fontname{Times} (m/s^2)','FontWeight','bold','fontsize',20);
    title('\fontname{黑体}随机路面-座椅垂向加速度响应\fontname{Times}','FontWeight','bold','fontsize',24);
    grid on;
    lgd_psh=['SkyHook Control' newline 'v=',num2str(v),'m/s'];
    lgd=['No Control' newline 'v=',num2str(v),'m/s'];
    legend([psha(i) pa(i)],{lgd_psh lgd},'Fontname','Times','FontSize',16);
    axis tight;
    

end
hold off;

saveas(gcf,'C级随机路面 座椅响应图 天棚原理控制器效果对比.png');

%% 运行完成
close all;
disp(['完成！' newline 'Completed!']);
